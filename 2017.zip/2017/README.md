# WWDC 2017 Scholarship Application

I'm going to keep the files off until after the deadline, so I'm sure that nobody will copy it 

Thanks :)
